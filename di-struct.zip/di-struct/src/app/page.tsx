import Image from 'next/image';

export default function Home() {
  return <main className="p-8">Landing page</main>;
}
