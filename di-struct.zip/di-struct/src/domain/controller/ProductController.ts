import { Db} from 'mongodb';
import dbClient from '@/lib/db/mongodb';

class ProductController {
  private dbName = process.env.DB_DATABASE;

  //   Connect DB here using function defined in lib
  private async getDb(): Promise<Db> {
    const client = await dbClient;
    const db = client.db(this.dbName);
    if (!db) throw new Error('database error');
    return db;
  }

  async getProducts(orgId: string): Promise<ProductType[]]> {
    const db = await this.getDb();

    // Perform data base operation and return data

   return []
  }
}

export default ProductController;
