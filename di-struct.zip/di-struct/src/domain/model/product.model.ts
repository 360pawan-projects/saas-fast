// db model fields are declared here
