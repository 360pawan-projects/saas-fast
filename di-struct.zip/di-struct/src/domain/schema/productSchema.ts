import { z } from 'zod';

const ProductSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  badgeImage: z.string(),
  hidden: z.number().optional(),
});

export type ProductType = z.infer<typeof ProductSchema>;
