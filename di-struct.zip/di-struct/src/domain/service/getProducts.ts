'use server';

import ProductController from '../controller/ProductController';
import stdMutationResponse from '@/shared/infrastructure/stdMutationResponse';
import { StandardMutationReturn } from '@/shared/infrastructure/StandardReturn';

const getProducts = async (
  requestedProductParams: RequestedProductType
): Promise<StandardMutationReturn> => {
  //  check for required params

  const productController = new ProductController();
  const fn = () => productController.getProducts(requestedProductParams);

  return stdMutationResponse({
    fn,
    failMessage: 'Error in fetching products',
  });
};

export default getProducts;
