// reuseable functions relates to server goes here
